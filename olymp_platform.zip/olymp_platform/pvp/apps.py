from django.apps import AppConfig


class PvpConfig(AppConfig):
    name = 'pvp'
